#Cleanup
#rm block
#rm block.decoded

echo $1
#Scriptupload in Container
docker cp TestcenterBlockdumpServerpart.sh peer0.org1.example.com:/opt/gopath/src/github.com/hyperledger/fabric/peer/block.sh
#Container Scriptaufruf
docker exec -it peer0.org1.example.com bash block.sh $1

#Wieder zurück, lokal Blockkopie von laufendem Container holen
docker cp peer0.org1.example.com:/opt/gopath/src/github.com/hyperledger/fabric/peer/block block$1.pb
#Block dekodieren und sichern im Arbeitsverzeichnis
../bin/./configtxlator proto_decode --input block$1.pb --type common.Block > block$1.decoded

#All block NOTDECODED:
#TRY DECODING: does not work with this command
#
#docker cp peer0.org1.example.com:/var/hyperledger/production/ledgersData/chains/chains/mychannel/blockfile_000000 blockfull.json
#
#docker exec -it peer0.org1.example.com bash
#../bin/configtxlator proto_decode --input blockfull.json --type common.Block
# SUBLIME:
#"enable_hexadecimal_encoding": false