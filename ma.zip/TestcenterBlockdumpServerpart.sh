#Containeraufruf
#Aktueller Block (dieser existiert natürlich noch nicht)
peer channel fetch $1 block -c mychannel
echo $1 
exit
